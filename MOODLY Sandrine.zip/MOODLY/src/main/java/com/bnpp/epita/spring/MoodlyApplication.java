package com.bnpp.epita.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoodlyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoodlyApplication.class, args);
	}

}
